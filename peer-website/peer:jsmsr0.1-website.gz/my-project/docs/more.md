## More

If you need APNIC LIR service, please move to AS139317
If you need RIPE LIR service, please move to [AS202888](https://t.me/@zh_210320)

If you need to access [Moe IX](https://moeqing-network.gitbook.io/moeix/moeix-cgo/vm-wang-luo-shuo-ming), please go to AS138211

If you have any questions and help please send a letter to [admin@jsmsr.com](mailto:admin@jsmsr.com)

We will reply you within 1-5 working days

Assignment of our [Address](https://docs.google.com/spreadsheets/u/0/d/1HfKHDhjWjBOkK28L1klU8EViNjf-0-G0oSaknUNHdic/htmlview)

You can get IPV6 tunnel support by filling out this form! IPV6 tunnelbroker request [URL](https://forms.gle/sFqpNTaWgsFxX7jk6)

