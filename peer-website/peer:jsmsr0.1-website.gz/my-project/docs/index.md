
# AS134478｜Jsmsr Experimental Network｜JEN 


## Graph V6
![](https://bgp.he.net/graphs/as134478-ipv6.svg)



access our network
For other regions, please send an email to [admin@jsmsr.com](mailto:admin@jsmsr.com)

##  AS-SET
AS-SET: AS-JSMSR

ASN: 134478 

## LookGlass
[lg.jsmsr.com](http://lg.jsmsr.com/)

location:SHA

##Special thanks

| ASN               |   Name   |
|---------------------|----------|
| AS138211       | MoeQing  | 
| AS139328       | MoeBee Network  | 
| AS206628       | Eric Net  | 
| AS142553       | Airs Project Private Network Main | 
| AS140731       | TOHU Public Internet  |
| AS139317       | Ningbo Dahuamao  |

And those who provide me with education and learning environment IX maintainers, because of you, there is JSMSR now.

