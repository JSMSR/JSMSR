## Peering
We are open and interconnected, 
and you can interconnect with us through the IX we access.

But we need to specify contract requirements or Loa power of attorney. 

## Location 
We provide services in the following locations

| Area                |   City   |
|---------------------|----------|
| **Europe**              |          |   
| Germany {DE}        |Frankfurt | 
|Netherlands {NL}        |Amsterdam | 
| **Asian**               |          | 
| Singapore           |Singapore | 
| HongKong            |Hong Kong |
| TaiWan              |TaiBei    |
| China               |Wuhan     |
| China               |Hangzhou  |
| China               |ChangSha  |
| China               |DEZhou    |
| China               |ZhengZhou    |
| China               |ShangHai    |
|**North America**      |          |
| United States       | Fremont  | 
| United States       |  Los Angeles  | 
| United States       | Seattle  | 
| United States       | San Jose  | 
| United States       | Los Angeles  |
| United States       | Dallas  |

## IX

| Excnge             |   CC |                                           City | IPV6                   |
|---------------------|----------|-----------------------------------------------|---------------------------|
|[ZXIX Hong Kong (Y)](https://bgp.tools/ixp/ZXIX%20Hong%20Kong%20%28Y%29)|HK|HongKong|2406:840:1f:1000:0:13:4478:1|
|[IXP LEN](https://bgp.he.net/exchange/IXP%20LEN)|US|Fremont|2001:7f8:d0:5553:0:2:d4e:1|
|[LOCIX Frankfurt](https://bgp.tools/ixp/LOCIX%20Frankfurt)|DE|Germany|2001:7f8:f2:e1:0:13:4478:2|
|[Poema IX](https://bgp.tools/ixp/Poema%20IX)|TW|Taipei City|2404:f4c0:f70e:1980::134:478|
|[MoeIX CSX](https://bgp.he.net/exchange/MoeIX%20CSX)|CN|ChangSha|2a0e:b107:5c3:a000:0:a13:4478:1|
|MoeIX SEA|US|Seattle|2a07:59c1:30ff:a000:13:4478:0:1|

### For more data, please visit PeeringDB and review it yourself!
[peeringDB](https://www.peeringdb.com/net/25544)


##start

Please fill out this form.

tunnelbroker request [URL](https://forms.gle/sFqpNTaWgsFxX7jk6)